<?php
/* Database connection start */
$servername = "sql109.epizy.com";
$username = "epiz_34008421";
$password = "Cajxzkzd7px3Fu";
$dbname = "epiz_34008421_comment_system";
$conn = mysqli_connect($servername, $username, $password, $dbname) or die("Connection failed: " . mysqli_connect_error());
if (mysqli_connect_errno()) {
    printf("Connect failed: %s\n", mysqli_connect_error());
    exit();
}
?>